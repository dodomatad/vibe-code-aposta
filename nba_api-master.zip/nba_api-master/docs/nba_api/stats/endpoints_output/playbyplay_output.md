PlayByPlay:

|    GAME_ID |   EVENTNUM |   EVENTMSGTYPE |   EVENTMSGACTIONTYPE |   PERIOD | WCTIMESTRING   | PCTIMESTRING   | HOMEDESCRIPTION                                            | NEUTRALDESCRIPTION                | VISITORDESCRIPTION                             | SCORE   | SCOREMARGIN   |
|-----------:|-----------:|---------------:|---------------------:|---------:|:---------------|:---------------|:-----------------------------------------------------------|:----------------------------------|:-----------------------------------------------|:--------|:--------------|
| 0022300061 |          2 |             12 |                    0 |        1 | 7:36 PM        | 12:00          |                                                            | Start of 1st Period (7:36 PM EST) |                                                |         |               |
| 0022300061 |          4 |             10 |                    0 |        1 | 7:36 PM        | 12:00          | Jump Ball Jokic vs. Davis: Tip to James                    |                                   |                                                |         |               |
| 0022300061 |          7 |              1 |                    7 |        1 | 7:37 PM        | 11:42          |                                                            |                                   | Davis 1' Dunk (2 PTS) (Russell 1 AST)          | 2 - 0   | -2            |
| 0022300061 |         10 |              1 |                  101 |        1 | 7:37 PM        | 11:15          | Jokic 7' Driving Floating Jump Shot (2 PTS) (Murray 1 AST) |                                   |                                                | 2 - 2   | TIE           |
| 0022300061 |         11 |              1 |                    1 |        1 | 7:37 PM        | 10:57          |                                                            |                                   | Prince 24' 3PT Jump Shot (3 PTS) (James 1 AST) | 5 - 2   | -3            |
| 0022300061 |         13 |              1 |                   75 |        1 | 7:38 PM        | 10:40          | Murray 6' Driving Finger Roll Layup (2 PTS)                |                                   |                                                | 5 - 4   | -1            |
| 0022300061 |         14 |              1 |                    1 |        1 | 7:38 PM        | 10:33          |                                                            |                                   | Prince 25' 3PT Jump Shot (6 PTS) (James 2 AST) | 8 - 4   | -4            |
| 0022300061 |         16 |              1 |                   80 |        1 | 7:38 PM        | 10:16          | Murray 26' 3PT Step Back Jump Shot (5 PTS)                 |                                   |                                                | 8 - 7   | -1            |
| 0022300061 |         18 |              2 |                   79 |        1 | 7:38 PM        | 10:03          |                                                            |                                   | MISS Russell 25' 3PT Pullup Jump Shot          |         |               |
| 0022300061 |         19 |              4 |                    0 |        1 | 7:38 PM        | 10:01          |                                                            |                                   | Reaves REBOUND (Off:1 Def:0)                   |         |               |

AvailableVideo:

|   VIDEO_AVAILABLE_FLAG |
|-----------------------:|
|                      1 |