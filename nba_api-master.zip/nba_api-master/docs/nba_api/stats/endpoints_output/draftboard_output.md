DraftBoard:

| PERSON_ID   | PLAYER_NAME   | SEASON   | ROUND_NUMBER   | ROUND_PICK   | OVERALL_PICK   | TEAM_ID   | TEAM_CITY   | TEAM_NAME   | TEAM_ABBREVIATION   | ORGANIZATION   | ORGANIZATION_TYPE   | HEIGHT   | WEIGHT   | POSITION   | JERSEY_NUMBER   | BIRTHDATE   | AGE   |
|-------------|---------------|----------|----------------|--------------|----------------|-----------|-------------|-------------|---------------------|----------------|---------------------|----------|----------|------------|-----------------|-------------|-------|