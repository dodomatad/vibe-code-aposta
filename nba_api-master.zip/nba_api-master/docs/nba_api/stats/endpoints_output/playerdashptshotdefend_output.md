DefendingShots:

| CLOSE_DEF_playerId   | GP   | G   | DEFENSE_CATEGORY   | FREQ   | D_FGM   | D_FGA   | D_FG_PCT   | NORMAL_FG_PCT   | PCT_PLUSMINUS   |
|----------------------|------|-----|--------------------|--------|---------|---------|------------|-----------------|-----------------|